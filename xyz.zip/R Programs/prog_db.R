library(RMySQL)

mydb = dbConnect(MySQL(), user='root', password='root', 
                 dbname='sakila', host='localhost')

## Lists the tables
dbListTables(mydb)

## List down the fields in a table
dbListFields(mydb, 'actor')

# Retrieving data
## 1. Saving in MySQLResult object
rs = dbSendQuery(mydb, "select * from actor")

## 2. Fetching the data from MySQL result object
#mydata = fetch(rs, n=2) # fetch only 2 records
mydata = fetch(rs, n=-1) # all the records

dbClearResult(rs)


## Write a dataframe as a table
dbWriteTable(mydb, name='mtcars', value=mtcars,
             append=T)
dbListTables(mydb)

rs = dbSendQuery(mydb, "select * from mtcars")
my_cars = fetch(rs, n=-1) # all the records

## Dropping the table
dbRemoveTable(mydb, "mtcars")
dbListTables(mydb)

dbDisconnect(mydb)

