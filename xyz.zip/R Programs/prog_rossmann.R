library(tidyverse)
setwd("C:/Training/Kaggle/Competitions/Rossmann Store Sales")

daily_sales <- read.csv("train_25.csv", 
                        stringsAsFactors = T)
store_info <- read.csv("store.csv", 
                       stringsAsFactors = T)

### Sum per store
sales_per_store <- daily_sales %>% 
              group_by(Store) %>% 
              summarise(tot_sales=sum(Sales, na.rm = T))

### Mean sales per day of week
avg_day <- daily_sales %>% 
           group_by(DayOfWeek) %>% 
           summarise(avg_sales=mean(Sales, na.rm = T))

ggplot(data = avg_day, 
       aes(x=DayOfWeek,y=avg_sales))+
  geom_bar(stat = 'identity', fill="plum" )

#######
## plot the freq counts for assortment for store
table(store_info$Assortment)
ggplot(data = store_info, 
       aes(x=Assortment,fill=Assortment ))+
  geom_bar( )

### join
sales_data <- daily_sales %>% 
    left_join(store_info, by = "Store")

### how many are missings in CompetitionMonth
### in store data?
sum(is.na(store_info$CompetitionOpenSinceMonth))

### Pie chart for store type in store
cnt_srt <- store_info %>% 
  group_by(StoreType) %>% 
  summarise(cnt=n())
## n() generates counts

pie(cnt_srt$cnt, labels = cnt_srt$StoreType)

# Calculate percentages
pct <- round(100*cnt_srt$cnt/sum(cnt_srt$cnt))
# Draw Pie chart
pie(cnt_srt$cnt,
    labels = paste(cnt_srt$StoreType, sep = ":", pct, "%"), 
    col = c("thistle","sandybrown","purple2","orchid2"), 
    main = "Store Type Percentage")
