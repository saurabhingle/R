w <- 34
s <- c(3,6,7,8,1)
g <- c("ft","rt","gc","hy")

d <- 45
class(d)
d <- as.integer(d)
class(d)

f <- TRUE
# or
f <- T
print(f)

g <- F 
print(g)

d <- 45
p <- d <= 50
print(p)

##### Lists #########
s <- list(9, 89, "dr", "mr", F, 3.45)
print(s)
print(s[4])

k <- list(name="ABC", age=23, gdr="M")
k$age
k$gdr
k['gdr'] # not recommended

ddd <- list(a = list(name="ABC", age=23, gdr="M"),
            b = list(name="SSS", age=33, gdr="F"),
            c = list(name="FFF", age=43, gdr="F"))
ddd$a$age

############# Factor ###############
x <- c("D","A","C","C","B","A", "D")
class(x)
fx <- factor(x)
class(fx)
x
fx
as.integer(x)
as.integer(fx)
fx

gdr <- c("m", "f","m", "m","f")
f_gdr <- factor(gdr)
f_gdr
as.integer(f_gdr)

## re-order the level
f_gdr <- factor(gdr, levels = c("m","f"))
f_gdr
as.integer(f_gdr)

########### Missing values ################
s <- NA
is.na(s)
d <- 4
is.na(d)
v <- c(45, 8, 9, NA, 23, NA, 3)
is.na(v)
sum(is.na(v)) # count missings in a vector
### Not A Number
g <- 0/0
g
is.nan(g)
is.na(g)
### Infinity
w <- 0/0
w
is.finite(w)
is.infinite(w)
is.na(w)
is.nan(w)

##### Matrix #####
m <- matrix(c(2,4,1,5,0,90), 3,2)
m
m <- matrix(c(2,4,1,5,0,90), 3,2, byrow = T)
m

m <- matrix(c(2,4,1), 3,2)
m
class(m)
##### binding ####
v1 <- c(3,4,6,7)
v2 <- c(3,7,4,0)
a <- cbind(v1, v2)
b <- rbind(v1, v2)
a
b
class(a)

v1 <- c(3,4,6,7,9)
v2 <- c(3,7,4)
a <- cbind(v1, v2)
a

sum(v1*v2) # dot product

###### Arrays
d <- array(dim = 4, data = c(3,5,6,0))
d

f <- array(dim = c(3,2), 
           data = c(3,5,6,3,1,2))
f
class(f)
# 3 dimensional array
h <- array(dim = c(3,4,2),
           data = 1:24)
h

############ Data Frame #########
df <- data.frame(name=c("A","B","C"),
                 age=c(24, 25, 20)
                 )
df
dim(df) # no. of rows and cols
str(df) # internal structure / meta data
df$A$age
mean(df$age)
colnames(df) # column names of data frame
names(df)
k <- list(name="ABC", age=23, gdr="M")
colnames(k)
names(k)

#############################################
a <- read.csv("Datasets\\A.csv")
a
a$IdNum

cars2018 <- read.csv("Datasets\\cars2018.csv")
dim(cars2018)
str(cars2018)
mean(cars2018$MPG)

cars2018 <- read.csv("Datasets\\cars2018.csv")                     
str(cars2018)
table(cars2018$Transmission)
table(cars2018$Aspiration)
# cross tab
table(cars2018$Transmission, cars2018$Aspiration)
addmargins(table(cars2018$Transmission, cars2018$Aspiration))

housing <- read.csv("C:/R/Datasets/Housing.csv", stringsAsFactors = T)
### how many houses are in preferred area?
table(housing$prefarea)
### how many houses don't driveway?
table(housing$driveway)
### how many houses that have driveways and are in preferred area?
addmargins( table(housing$prefarea, housing$driveway,
      dnn = c("Pref area","Drive way")) )

### What percentage of houses are in preferred area?
prop.table( table(housing$prefarea) )*100

### What percentage of houses which don't driveway?
prop.table( table(housing$driveway))*100
### What percentage of houses that have driveways and are in preferred area?
addmargins( prop.table( table(housing$prefarea, housing$driveway,
                  dnn = c("Pref area","Drive way"))  )*100 )


bolyw <- read.csv("C:/R/Datasets/Bollywood_2015_2.csv",
                  header = F)
colnames(bolyw) <- c("movie",'collection','budget','verdict')

diam <- read.csv2("C:/R/Datasets/Diamonds.csv")
str(diam)

##### Setting a folder as working directory
setwd("C:/R/Datasets/")
bolyw <- read.csv("Bollywood_2015_2.csv",header = F)
diam <- read.csv2("Diamonds.csv")
str(diam)

#### Excel sheet
library(readxl)
bank <- read_excel("Datasets\\bankruptcy.xlsx",sheet = "data")
bank
### Writing to a file
df <- data.frame(name=c("A","B","C"),
                 age=c(24, 25, 20),
                 gdr=c("m","f","m"))
df
write.csv(df, "Datasets\\new1.csv", row.names = F)
df <- read.csv("Datasets\\new1.csv")
df
### Subsetting a vector
v <- c(30, 89, 45, 21, 50, 34, 49, 84, 67)

v[2]
v[2:5]
c(v[2], v[6], v[1]) # 2nd, 6th and 1st elements
v > 50
v[v>50]

### Subsetting a matrix
m = matrix(1:20, 4,5)
m
m[2,3]
m[2, 2:5]
m[2:4, 3:5]
m[3, ]
m[,4]
m[,4,drop=F]
m[,2:4]

### Subsetting a data frame
setwd("C:/R/Datasets/")
cars2018 <- read.csv("cars2018.csv",stringsAsFactors = T)
ss1 <- subset(cars2018, MPG>20)
ss1 <- subset(cars2018, MPG>20 & Transmission=="Automatic")
ss2 <- subset(cars2018, MPG>20 & Transmission %in% 
                                  c("Automatic","CVT"))
# 4th, 405th, 678th row
ss3 <- cars2018[c(4,405,678),]

# 4th, 6th, 8th column
ss4 <- cars2018[, c(4,6,8)]
#or
ss4 <- subset( cars2018, select=c(Cylinders, Transmission, Aspiration))
#or
ss4 <- subset( cars2018, select=c(4,6,8))

### Resident datasets in R
data() # lists down all the resident datasets
## Loading a resident dataset
data(Formaldehyde)
data(OrchardSprays)
data("mtcars")

### Exercise
diam <- read.csv2("Diamonds.csv", stringsAsFactors = T)
ss <- subset(diam, color=="J" & cut=="Premium")

