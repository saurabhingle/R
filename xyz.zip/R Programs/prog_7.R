library(tidyverse)
setwd("C:/R/Datasets/")

cars93 <- read.csv("Cars93.csv", stringsAsFactors = T)

### Scatter Plot

ggplot(data = cars93, aes(x=MPG.city, y=Price)) + 
  geom_point() + labs(x="Milage", y="Price")


ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=AirBags)) + 
  geom_point() + labs(x="Milage", y="Price")

ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=EngineSize)) + 
  geom_point() + labs(x="Milage", y="Price")

ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,size=EngineSize)) + 
  geom_point(color="violetred",alpha=0.4) +
  labs(x="Milage", y="Price")

ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,size=EngineSize,
           color=AirBags)) + 
  geom_point(alpha=0.4) +
  labs(x="Milage", y="Price")

#### Smoothing
ggplot(data = cars93, aes(x=MPG.city, y=Price)) + 
  geom_point() + geom_smooth()+
  labs(x="Milage", y="Price")

ggplot(data = cars93, aes(x=MPG.city, y=Price)) + 
  geom_point() + 
  geom_smooth(method = "lm", se = F)+
  labs(x="Milage", y="Price")

ggplot(data = cars, aes(x=dist, y=speed)) + 
  geom_point() + 
  geom_smooth(method = "lm", se = F)+
  labs(x="Distance", y="Speed")

### Boxplot
ggplot(data = cars93, aes(y=Price))+
  geom_boxplot()

ggplot(data = cars93, aes(x=Price))+
  geom_boxplot()

ggplot(data = cars93, 
       aes(y=Price, x=AirBags, colour=AirBags ))+
  geom_boxplot()

ggplot(data = cars93, 
       aes(y=Price, x=AirBags, fill=AirBags ))+
  geom_boxplot()

### Histogram
ggplot(data = cars93,
       aes(x=Price))+ 
  geom_histogram(fill="rosybrown2", color="red")

### Density Plot
ggplot(data = cars93,
       aes(x=Price))+ 
  geom_density(fill="rosybrown2", color="red")

### Bar Plot
barplot(table(cars93$Type), beside = T,
        main = "Types of Cars",
        xlab = "Types", ylab = "Count")

ggplot(data = cars93, aes(x=Type, fill = Type)) +
  geom_bar()

ggplot(data = cars93, aes(x=Type, fill = AirBags)) +
  geom_bar(position = "dodge")

## Plotting group by summary
ss_cars <- cars93 %>% 
  filter(Type=="Midsize") %>% 
  group_by(AirBags) %>% 
  summarise(avg_price = mean(Price, na.rm = T))

ggplot(data = ss_cars, 
       aes(x=AirBags, y=avg_price,fill=AirBags))+
  geom_bar(stat = 'identity') +
  labs(y="Average Price", x="Air Bag")

### Facet Grid
ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=AirBags)) + 
  geom_point() + labs(x="Milage", y="Price")

ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=AirBags)) + 
  geom_point() + facet_grid(.~AirBags)+
  labs(x="Milage", y="Price")

ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=AirBags)) + 
  geom_point() + facet_grid(AirBags~.)+
  labs(x="Milage", y="Price")

ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=AirBags)) + 
  geom_point() + facet_grid(Type~AirBags)+
  labs(x="Milage", y="Price")

### Changing the Theme
ggplot(data = cars93, 
       aes(x=MPG.city, y=Price,color=AirBags)) + 
  geom_point() + labs(x="Milage", y="Price")+
  ggtitle("Scatter Plot")+theme_bw()+
  theme(plot.title = element_text(hjust = 0.5))

#### Ex2 
autocol <- read.csv("AutoCollision.csv")
ggplot(data = autocol,
       aes(x = Vehicle_Use, y = Claim_Count, fill = Vehicle_Use))+
  geom_boxplot()+
  scale_fill_brewer(palette = "RdYlBu")

### Ex3
orns <- read.csv("Ornstein.csv", stringsAsFactors = T)
ggplot(data = orns, aes(x = nation, fill = sector)) +
  geom_bar()
ggplot(data = orns, aes(x = nation, fill = sector)) +
  geom_bar(position = 'dodge')

### Ex4
ggplot(data = orns, aes(x=assets, y=interlocks, colour = sector))+
  geom_point() +
  facet_grid(.~nation)

### Ex 5
data("mtcars")
mtcars$gear <- factor(mtcars$gear)
ggplot(data = mtcars, aes(x=disp, y=mpg, colour = gear)) + 
  geom_point() + 
  labs(x="Displacement", y="Miles Per Gallon",
       colour="Gear")
